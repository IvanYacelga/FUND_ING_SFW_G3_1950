import pymongo
from pymongo import MongoClient

class MongoDBManager:
    def __init__(self):
        self.connectionString = "mongodb+srv://kleverdavid165:POO2025@cluster0.0hjyg.mongodb.net/"
        self.databaseName = "strategyJami"
        self.client = None
        self.db = None
        self.collection = None
        self.connect()
        
    def connect(self):
        try:
            self.client = MongoClient(self.connectionString)
            self.db = self.client[self.databaseName]
            self.collection = self.db['arrayKlever']
            print("Conexión a MongoDB establecida con éxito")
        except Exception as e:
            print(f"Error al conectar a MongoDB: {e}")
            raise RuntimeError("No se pudo conectar a la base de datos")
    
    def saveSortResult(self, unsorted, size, algorithm, sortedList):
        try:
            data = {
                "unsorted": unsorted,
                "size": size, 
                "sort algorithm": algorithm,
                "sorted": sortedList
            }
            self.collection.insert_one(data)
            print("Datos guardados en MongoDB")
        except Exception as e:
            print(f"Error al guardar en MongoDB: {e}")
    
    def closeConnection(self):
        if self.client:
            self.client.close()
