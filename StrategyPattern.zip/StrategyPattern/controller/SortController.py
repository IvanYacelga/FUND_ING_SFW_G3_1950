from model.SortingContext import SortingContext
from utils.MongoDBManager import MongoDBManager

class SortController:
    def __init__(self):
        self.context = SortingContext()
        self.dbManager = MongoDBManager()

    def sort(self, inputData):
        data = [int(x) for x in inputData.split(",")]
        if len(data) < 2:
            raise ValueError("Array must have at least 2 elements")

        self.context.setStrategy(len(data))
        sortedData = self.context.sort(data)

        self.dbManager.saveSortResult(inputData, len(data), self.context.strategy.__class__.__name__, ",".join(map(str, sortedData)))
        return sortedData
